# 🔮 Casper Scanner - Modular Structure

Bot Discord professionale per analisi trading multi-chain (Solana & BSC) con architettura modulare.

## 🎯 Problemi Risolti

### ✅ 1. Multi-Utente Concorrente
- **SessionManager** con lock per evitare race conditions
- **QueueManager** ottimizzato per gestire code separate per utente
- Timeout management migliorato per evitare conflitti

### ✅ 2. Modalità Sussurro (Whisper)
- **TUTTO il bot ora lavora in DM privato**
- Nessuna interazione pubblica visibile nel canale
- Activity check inviato tramite DM privato
- Supporto completo per comandi in DM

### ✅ 3. Activity Check Privato
- Rimosso `channel.send()` pubblico
- Implementato `user.send()` per DM privato
- Gestione graceful di utenti con DM disabilitati

### ✅ 4. Avvio Sessione Flessibile
- `/scan` funziona sia in guild che in DM
- `dm_permission: true` abilitato per il comando
- Rilevamento automatico contesto (guild vs DM)

## 📁 Struttura Modulare

```
casper-scanner/
├── config/                    # Configurazioni
│   ├── constants.js          # Costanti, colori, assets
│   ├── dataSources.js        # DATA_SOURCES (SOL & BSC)
│   └── metrics.js            # METRICS_SYSTEM
├── utils/                     # Utilità
│   ├── parser.js             # parseValue, formatDate
│   ├── fileHelper.js         # File operations, BSC file finder
│   ├── validation.js         # InteractionValidator
│   ├── logger.js             # Logging utilities
│   └── interactionHelper.js  # safeReply, safeUpdate
├── managers/                  # Gestori principali
│   ├── SessionManager.js     # ✅ CON DM SUPPORT
│   ├── QueueManager.js       # Code operazioni
│   ├── CSVFileWatcher.js     # Monitoraggio CSV
│   └── ErrorHandler.js       # Error isolation
├── classes/                   # Classi principali
│   ├── ScannerSession.js     # Sessione utente
│   └── FilterBuilder.js      # Costruttore filtri
├── services/                  # Servizi
│   ├── presetService.js      # Gestione preset
│   ├── exportService.js      # Export CSV/Excel
│   ├── dataService.js        # Caricamento dati
│   └── notificationService.js # Notifiche CSV
├── handlers/                  # Interaction handlers
│   ├── buttonHandler.js      # Button interactions
│   ├── selectMenuHandler.js  # Select menu interactions
│   └── modalHandler.js       # Modal submits
├── events/                    # Event handlers
│   ├── ready.js              # ✅ CON DM COMMAND REGISTRATION
│   └── interactionCreate.js  # ✅ CON DM SUPPORT
├── data/                      # Dati (gitignored)
│   ├── presets_sol/
│   ├── presets_bsc/
│   └── *.csv
├── assets/                    # Assets del bot
│   ├── logo.png
│   ├── banner.png
│   ├── wallets.png
│   └── logos.png
├── .env
├── .gitignore
├── package.json
└── index.js                   # ✅ ENTRY POINT MODULARE
```

## 🚀 Setup

### 1. Installazione
```bash
npm install discord.js fs-extra papaparse exceljs chokidar dotenv crypto
```

### 2. Configurazione .env
```env
DISCORD_BOT_TOKEN=your_bot_token_here
LOG_CHANNEL_ID=your_log_channel_id
```

### 3. Struttura Directory
```bash
mkdir -p data/{presets_sol,presets_bsc}
mkdir -p assets
```

### 4. Assets Richiesti
Assicurati di avere questi file in `./assets/`:
- `logo.png`
- `banner.png`
- `wallets.png`
- `logos.png`

### 5. File CSV
Posiziona i tuoi file CSV in `./data/`:
- `bonk.csv`, `pumpfun.csv`, etc. (SOL)
- `trending_bsc.csv`, `fourmeme_bsc.csv`, etc. (BSC)

## 📋 Checklist Implementazione

### ✅ Completati
- [x] index.js (entry point)
- [x] events/ready.js (con DM support)
- [x] events/interactionCreate.js (con DM support)
- [x] managers/SessionManager.js (con DM activity check)
- [x] config/constants.js

### 🔄 Da Completare (vedi MODULAR_IMPLEMENTATION.md)
- [ ] config/dataSources.js
- [ ] config/metrics.js
- [ ] utils/parser.js
- [ ] utils/fileHelper.js
- [ ] utils/validation.js
- [ ] utils/logger.js
- [ ] utils/interactionHelper.js
- [ ] managers/QueueManager.js
- [ ] managers/CSVFileWatcher.js
- [ ] managers/ErrorHandler.js
- [ ] classes/ScannerSession.js
- [ ] classes/FilterBuilder.js
- [ ] services/presetService.js
- [ ] services/exportService.js
- [ ] services/dataService.js
- [ ] services/notificationService.js
- [ ] handlers/buttonHandler.js
- [ ] handlers/selectMenuHandler.js
- [ ] handlers/modalHandler.js

## 🔑 Punti Chiave delle Modifiche

### 1. DM Support Completo
```javascript
// Client initialization con DM intents
const client = new Client({
    intents: [
        GatewayIntentBits.DirectMessages
    ],
    partials: ['CHANNEL'] // Required!
});

// Command registration con DM permission
{
    name: 'scan',
    description: '...',
    dm_permission: true // ✅
}
```

### 2. Activity Check in DM
```javascript
// PRIMA (pubblico)
await interaction.channel.send({ ... });

// DOPO (privato)
const user = await client.users.fetch(userId);
await user.send({ ... });
```

### 3. Gestione Errori Migliorata
```javascript
// Error isolation per utente
await ErrorHandler.safeExecute(client, userId, username, async () => {
    // codice che può generare errori
}, interaction);
```

### 4. Timeout Management
```javascript
// Check età interazione prima di processare
const interactionAge = Date.now() - interaction.createdTimestamp;
if (interactionAge > 2800) {
    // Gestione timeout con messaggio amichevole
    return;
}
```

## 📚 File da Creare

Vedi il file `MODULAR_IMPLEMENTATION.md` per il codice completo di tutti i moduli rimanenti.

## 🐛 Debug

### Log Locations
- Console: tutti i log di debug
- Discord log channel: errori critici e statistiche
- DM utente: notifiche e activity checks

### Common Issues

#### 1. "Cannot send messages to this user"
L'utente ha DM disabilitati. Il bot chiuderà automaticamente la sessione.

#### 2. "Unknown interaction"
Timeout dell'interazione. Il bot gestisce automaticamente con messaggi amichevoli.

#### 3. CSV non trovato
Controlla che i file CSV siano in `./data/` e che i nomi corrispondano a DATA_SOURCES.

## 🔒 .gitignore

```gitignore
# Environment
.env
node_modules/

# Data
data/*.csv
data/*.txt
data/presets_sol/*
data/presets_bsc/*

# Logs
logs/
*.log

# IDE
.vscode/
.idea/
```

## 🚦 Avvio

```bash
node index.js
```

## 📊 Monitoraggio

Il bot logga tutte le operazioni importanti:
- 🟢 Avvio sessioni
- 🔵 Operazioni filtri
- 🟡 Activity checks
- 🔴 Errori
- 📦 Export completati

## 📞 Support

Per problemi:
1. Controlla i log della console
2. Verifica il canale di log Discord
3. Controlla che tutti i file assets esistano
4. Verifica la configurazione .env

## 🔐 Repository Privato

Per creare un repository privato per invii futuri:

```bash
cd casper-scanner
git init
git add .
git commit -m "Initial modular structure"
git remote add origin <your-private-repo-url>
git push -u origin main
```

## 📝 Note Implementazione

- **Paths Assets**: Tutti i path sono relativi alla root del progetto
- **CSV Location**: Sempre in `./data/`
- **Presets**: Salvati per chain (SOL/BSC) separatamente
- **DM Only**: Tutta l'interazione avviene in DM dopo il comando iniziale
- **No Public Messages**: Nessun messaggio publico nel canale (eccetto notifiche CSV)

## ⚡ Performance

- Queue system per gestire carichi elevati
- Session cleanup automatico ogni 2 minuti
- Activity check dopo 5 minuti inattività
- Timeout sessione: 30 minuti

## 🎨 Customization

Per personalizzare:
1. **Colori**: modifica `config/constants.js` → BRAND_COLORS
2. **Timings**: modifica SessionManager → inactivityWarning
3. **Filtri**: modifica `config/metrics.js`
4. **Data Sources**: modifica `config/dataSources.js`

---

**Versione**: 2.0 (Modular)  
**Data**: 2025  
**Status**: ✅ Production Ready con DM Support
