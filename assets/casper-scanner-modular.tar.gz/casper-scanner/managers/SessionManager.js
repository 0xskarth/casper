// ========================================
// SESSION MANAGER - CON SUPPORTO DM PRIVATO
// ========================================
const EventEmitter = require('events');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ScannerSession = require('../classes/ScannerSession');

class SessionManager extends EventEmitter {
    constructor(client) {
        super();
        this.client = client;
        this.sessions = new Map();
        this.locks = new Map();
        this.activityTimers = new Map();
        this.maxSessionAge = 30 * 60 * 1000;
        this.inactivityWarning = 5 * 60 * 1000;
        
        setInterval(() => this.cleanup(), 2 * 60 * 1000);
    }

    async getSession(userId, channelId = null) {
        while (this.locks.get(userId)) {
            await new Promise(resolve => setTimeout(resolve, 50));
        }

        let session = this.sessions.get(userId);
        if (!session) {
            session = new ScannerSession(userId, channelId);
            this.sessions.set(userId, session);
        }
        
        session.lastInteraction = Date.now();
        this.resetActivityTimer(userId);
        
        return session;
    }

    async withLock(userId, operation) {
        this.locks.set(userId, true);
        try {
            return await operation();
        } finally {
            this.locks.delete(userId);
        }
    }

    resetActivityTimer(userId) {
        if (this.activityTimers.has(userId)) {
            clearTimeout(this.activityTimers.get(userId));
        }

        const timer = setTimeout(async () => {
            await this.sendActivityCheckDM(userId);
        }, this.inactivityWarning);

        this.activityTimers.set(userId, timer);
    }

    // ✅ FIX: Activity check ora funziona in DM PRIVATO
    async sendActivityCheckDM(userId) {
        const session = this.sessions.get(userId);
        if (!session) return;

        const timeSinceLastInteraction = Date.now() - session.lastInteraction;
        
        if (timeSinceLastInteraction < this.inactivityWarning - 10000) {
            console.log(`[ACTIVITY_CHECK] User ${userId} recently active, skipping`);
            return;
        }

        console.log(`[ACTIVITY_CHECK] Sending DM to user ${userId}`);

        try {
            // ✅ INVIO IN DM INVECE CHE NEL CANALE
            const user = await this.client.users.fetch(userId);
            if (!user) return;

            const embed = new EmbedBuilder()
                .setTitle('⏰ Sei Ancora Attivo?')
                .setDescription('La tua sessione scanner è stata inattiva per 5 minuti.\n\n' +
                    '**Clicca "Sì" entro 60 secondi per continuare**, oppure la sessione verrà chiusa automaticamente.')
                .setColor('#FFA500')
                .setFooter({ text: 'La sessione scadrà tra 60 secondi...' })
                .setTimestamp();

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('activity_check_yes')
                        .setLabel('✅ Sì, Sono Qui')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('👋'),
                    new ButtonBuilder()
                        .setCustomId('activity_check_end')
                        .setLabel('❌ Chiudi Sessione')
                        .setStyle(ButtonStyle.Danger)
                );

            // ✅ INVIA IN DM
            const message = await user.send({
                embeds: [embed],
                components: [row]
            });

            const cleanupTimer = setTimeout(async () => {
                this.deleteSession(userId);
                
                try {
                    await message.edit({
                        embeds: [new EmbedBuilder()
                            .setTitle('❌ Sessione Chiusa')
                            .setDescription('La tua sessione scanner è stata chiusa per inattività.\n\n' +
                                'Esegui `/scan` per avviare una nuova sessione.')
                            .setColor('#FF0000')
                            .setTimestamp()],
                        components: []
                    });
                } catch (e) {
                    console.error('[ACTIVITY_CHECK] Failed to edit DM:', e);
                }

                console.log(`[ACTIVITY_CHECK] Session closed for user ${userId}`);
            }, 60000);

            session.activityCheckTimer = cleanupTimer;

        } catch (error) {
            console.error('[ACTIVITY_CHECK] Error sending DM:', error);
            
            // ✅ Se non può inviare DM, elimina la sessione (utente ha DM chiusi)
            if (error.code === 50007) {
                console.log(`[ACTIVITY_CHECK] User ${userId} has DMs disabled, closing session`);
                this.deleteSession(userId);
            }
        }
    }

    cleanup() {
        const now = Date.now();
        for (const [userId, session] of this.sessions.entries()) {
            if (now - session.lastInteraction > this.maxSessionAge) {
                console.log(`[CLEANUP] Removing expired session for user ${userId}`);
                this.deleteSession(userId);
            }
        }
    }

    deleteSession(userId) {
        if (this.activityTimers.has(userId)) {
            clearTimeout(this.activityTimers.get(userId));
            this.activityTimers.delete(userId);
        }

        const session = this.sessions.get(userId);
        if (session?.activityCheckTimer) {
            clearTimeout(session.activityCheckTimer);
        }

        if (session?.exportSessionTimer) {
            clearTimeout(session.exportSessionTimer);
            session.exportSessionTimer = null;
        }

        this.sessions.delete(userId);
        this.locks.delete(userId);
        
        // Clear queue if queueManager is available
        if (this.client.queueManager) {
            this.client.queueManager.clearUserQueue(userId);
        }
        
        console.log(`[SESSION] Deleted session for user ${userId}`);
    }
}

module.exports = SessionManager;
